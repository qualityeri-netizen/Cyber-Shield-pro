package com.cybershield.pro

import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.Alignment
import androidx.compose.ui.platform.LocalContext

data class AppFinding(
    val appName: String,
    val packageName: String,
    val permissions: List<String>
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CyberShieldScreen() }
    }
}

@Composable
fun CyberShieldScreen() {
    val context = LocalContext.current
    var findings by remember { mutableStateOf<List<AppFinding>>(emptyList()) }
    var scanned by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("هنوز اسکن انجام نشده است") }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFF00C2A8),
            background = Color(0xFF101820),
            surface = Color(0xFF182630)
        )
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Text("CYBER SHIELD PRO", style = MaterialTheme.typography.headlineSmall,
                        color = Color(0xFF00C2A8), fontWeight = FontWeight.Bold)
                    Text("مرکز امنیت گوشی", color = Color.LightGray)
                }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                        Column(Modifier.fillMaxWidth().padding(16.dp)) {
                            Text("وضعیت محافظت", style = MaterialTheme.typography.titleMedium)
                            Spacer(Modifier.height(6.dp))
                            Text(status, color = Color.LightGray)
                            Spacer(Modifier.height(12.dp))
                            Button(
                                onClick = {
                                    findings = scanLaunchableApps(context.packageManager)
                                    scanned = true
                                    status = "بررسی مجوزهای برنامه‌های قابل‌مشاهده انجام شد"
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("اسکن امنیت برنامه‌ها") }
                        }
                    }
                }
                item {
                    Text(
                        "گزارش بررسی",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        "این نسخه مجوزهای اعلام‌شده توسط برنامه‌ها را بررسی می‌کند؛ تشخیص قطعی شنود یا نفوذ نیست.",
                        color = Color.LightGray,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                if (scanned) {
                    item {
                        Text("برنامه‌های بررسی‌شده: ${findings.size}", color = Color(0xFF00C2A8))
                    }
                    items(findings) { app ->
                        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                            Column(Modifier.fillMaxWidth().padding(14.dp)) {
                                Text(app.appName, fontWeight = FontWeight.SemiBold)
                                Text(app.packageName, color = Color.Gray, style = MaterialTheme.typography.labelSmall)
                                Spacer(Modifier.height(6.dp))
                                if (app.permissions.isEmpty()) {
                                    Text("مجوز حساسِ قابل‌بررسی پیدا نشد", color = Color.LightGray)
                                } else {
                                    Text("مجوزهای حساس اعلام‌شده:", color = Color(0xFFFFC857))
                                    app.permissions.forEach { Text("• $it", color = Color.LightGray) }
                                }
                            }
                        }
                    }
                    item {
                        Text(
                            "توجه: فهرست کامل همه برنامه‌های سیستمی در این نسخه نمایش داده نمی‌شود. اندروید دسترسی یک برنامه عادی به داده‌های امنیتی سایر برنامه‌ها را محدود می‌کند.",
                            color = Color.Gray,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                } else {
                    item {
                        Text("برای شروع، دکمه اسکن را بزن.", color = Color.LightGray)
                    }
                }
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("حذف خودکار فایل یا برنامه: ", color = Color.LightGray)
                        Text("غیرفعال", color = Color(0xFF00C2A8), fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

private fun scanLaunchableApps(pm: PackageManager): List<AppFinding> {
    val sensitive = mapOf(
        "android.permission.RECORD_AUDIO" to "میکروفون",
        "android.permission.CAMERA" to "دوربین",
        "android.permission.ACCESS_FINE_LOCATION" to "موقعیت دقیق",
        "android.permission.ACCESS_COARSE_LOCATION" to "موقعیت تقریبی",
        "android.permission.READ_CONTACTS" to "مخاطبین",
        "android.permission.READ_SMS" to "پیامک‌ها",
        "android.permission.READ_CALL_LOG" to "سوابق تماس",
        "android.permission.READ_PHONE_STATE" to "وضعیت تلفن"
    )

    val intent = android.content.Intent(android.content.Intent.ACTION_MAIN).addCategory(
        android.content.Intent.CATEGORY_LAUNCHER
    )
    return pm.queryIntentActivities(intent, PackageManager.GET_META_DATA)
        .distinctBy { it.activityInfo.packageName }
        .mapNotNull { resolved ->
            val pkg = resolved.activityInfo.packageName
            try {
                val info = pm.getPackageInfo(pkg, PackageManager.GET_PERMISSIONS)
                val declared = info.requestedPermissions.orEmpty()
                val labels = declared.mapNotNull { sensitive[it] }.distinct()
                AppFinding(
                    appName = resolved.loadLabel(pm).toString(),
                    packageName = pkg,
                    permissions = labels
                )
            } catch (_: Exception) {
                null
            }
        }
        .sortedBy { it.appName.lowercase() }
}
